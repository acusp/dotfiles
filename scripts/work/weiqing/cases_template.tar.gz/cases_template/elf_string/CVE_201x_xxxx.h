
#ifndef __CVE_201x_xxxx_H__
#define __CVE_201x_xxxx_H__

#include "WJNativeCase.h"
#include "WJNativeRet.h"
#include "WJNativeEnvironment.h"

namespace wheeljack {
    class CVE_201x_xxxx_CASE : public WJNativeCase {
    public:
        CVE_201x_xxxx_CASE();
        virtual ~CVE_201x_xxxx_CASE();
    };
}

#endif /* __CVE_201x_xxxx_H__ */
