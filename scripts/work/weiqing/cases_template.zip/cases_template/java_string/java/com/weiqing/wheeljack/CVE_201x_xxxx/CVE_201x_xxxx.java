
package com.weiqing.wheeljack;

import android.content.Context;
import android.util.Log;

public class CVE_201x_xxxx extends JavaCase {
    private final String TAG = "CVE_201x_xxxx";
    String mXXXDexPath = null;

    public CVE_201x_xxxx() {
        JavaBlock CVE_201x_xxxx_BLOCK0 = new JavaBlock("CVE_201x_xxxx_BLOCK0") {
                @Override
                public int blockFunction(Context context) {
                    int exitCode = JavaRet.WJ_RET_ERROR_UNKNOW.getResult();
                    String toBeSearched = "xxxxxx";

                    if (mXXXDexPath == null) {
                        exitCode = JavaRet.WJ_RET_OK_NO_EXIST_NO_JAVA_APK.getResult();
                     // exitCode = JavaRet.WJ_RET_ERROR_JAVA_LIB_NOTFOUND.getResult();
                    } else {
                        if (isStringExist(mXXXDexPath, toBeSearched)) {
                            exitCode = JavaRet.WJ_RET_OK_PATCHED.getResult();
                        } else {
                            exitCode = JavaRet.WJ_RET_OK_VULNERABLE.getResult();
                        }
                    }

                    return exitCode;
                }
            };

        JavaBlock[] CVE_201x_xxxx_BLOCKS = new JavaBlock[] {
            CVE_201x_xxxx_BLOCK0,
            null
        };

        mInfo = new JavaCaseInfo(CVE_201x_xxxx_BLOCKS);
    }

    @Override
    public void onSetUp(String blockName, Context context) {
        if (mXXXDexPath == null) {
            mXXXDexPath = findApkDexFullPath("messaging.apk", context);
                     // = findFrameworkDexFullPath("services.jar", context);
        }
    }
}
