package com.weiqing.wheeljack;

import android.content.Context;
import android.util.Log;

public class CVE_201x_xxxx extends JavaCase {
    private final String TAG = "CVE_201x_xxxx";
    public CVE_201x_xxxx() {
        HtmlBlock CVE_201x_xxxx_BLOCK0 = new HtmlBlock("CVE_201x_xxxx_BLOCK0") {
            @Override
            public String getScanCode(Context context) {
                StringBuffer data = new StringBuffer();
                data.append("<html> \n");
                data.append("<script> \n");
                data.append("var array = []; \n");
                data.append("var funky = { \n");
                data.append("      toJSON: function() { array.length = 1; return \"funky\"; } \n");
                data.append("}; \n");
                data.append("for (var i = 0; i < 10; i++) array[i] = i; \n");
                data.append("array[0] = funky; \n");
                data.append("var expected = '[\"funky\",null,null,null,null,null,null,null,null,null]'; \n");
                data.append("var expected2 = '[\"funky\"]'; \n");
                data.append("var result = JSON.stringify(array); \n");
                // data.append("console.log(result); \n");
                data.append("if(result===expected||result===expected2){ \n");
                data.append("     console.log(\"CVE_201x_xxxx_BLOCK0=patched\"); \n");
                data.append("}else{ \n");
                data.append("     console.log(\"CVE_201x_xxxx_BLOCK0=vulnerable\"); \n");
                data.append("} \n");
                data.append("</script> \n");
                data.append("</html> \n");

                return data.toString();
            }
        };

        HtmlBlock[] CVE_201x_xxxx_BLOCKS = new HtmlBlock[] {
            CVE_201x_xxxx_BLOCK0,
            null
        };

        mHtmlCaseInfo = new HtmlCaseInfo(CVE_201x_xxxx_BLOCKS);
    }
}
