package com.weiqing.wheeljack;

import android.content.Context;
import android.util.Log;

/**
 * Created by Hangxu on 10/16/17.
 */

public class CVE_201x_xxxx extends JavaCase {
    private final String TAG = "CVE_201x_xxxx";

    public CVE_201x_xxxx() {
        JavaBlock CVE_201x_xxxx_BLOCK0 = new JavaBlock(
            "CVE_201x_xxxx_BLOCK0"
            ) {
                @Override
                public int blockFunction(Context context) {
                    int exitCode = JavaRet.WJ_RET_ERROR_UNKNOW.getResult();
                    try {
                        boolean MethodExist = false;
                        try {
                            // FIXME
                            getXXXClass().getDeclaredMethod("createAccountRedacted", int.class, String.class, long.class);
                            MethodExist = true;
                        } catch (NoSuchMethodException e) {
                            Log.e(TAG, "Get method failed", e);
                        } catch (SecurityException e) {
                            Log.e(TAG, "Security exception", e);
                        }

                        if (MethodExist) {
                            exitCode = JavaRet.WJ_RET_OK_PATCHED.getResult();
                        } else {
                            exitCode = JavaRet.WJ_RET_OK_VULNERABLE.getResult();
                        }
                    } catch (Exception e) {
                        exitCode = JavaRet.WJ_RET_ERROR_UNKNOW.getResult();
                    } finally {
                        Log.e(TAG, "Exit: " + exitCode);
                    }

                    return exitCode;
                }
            };

        JavaBlock CVE_201x_xxxx_BLOCK1 = new JavaBlock(
            "CVE_201x_xxxx_BLOCK1"
            ) {
                @Override
                public int blockFunction(Context context) {
                    int exitCode = JavaRet.WJ_RET_ERROR_UNKNOW.getResult();
                    try {
                        boolean FieldExist = false;
                        try {
                            // FIXME
                            getXXXClass().getDeclaredField("REDACTED_ACCOUNT");
                            FieldExist = true;
                        } catch (NoSuchFieldException e) {
                            Log.e(TAG, "Get field failed", e);
                        } catch (SecurityException e) {
                            Log.e(TAG, "Security exception", e);
                        }

                        if (FieldExist) {
                            exitCode = JavaRet.WJ_RET_OK_PATCHED.getResult();
                        } else {
                            exitCode = JavaRet.WJ_RET_OK_VULNERABLE.getResult();
                        }
                    } catch (Exception e) {
                        exitCode = JavaRet.WJ_RET_ERROR_UNKNOW.getResult();
                    } finally {
                        Log.e(TAG, "Exit: " + exitCode);
                    }

                    return exitCode;
                }
            };

        JavaBlock[] CVE_201x_xxxx_BLOCKS = new JavaBlock[] {CVE_201x_xxxx_BLOCK0,
                                                            CVE_201x_xxxx_BLOCK1,
                                                            null};

        mInfo = new JavaCaseInfo(CVE_201x_xxxx_BLOCKS);
    }

    // FIXME
    private Class<?> getXXXClass() {
        Class<?> xxxClass = null;

        try {
            xxxClass = Class.forName("android.content.SyncInfo");
        } catch (ClassNotFoundException e) {
            Log.d(TAG, "Class not found", e);
        }

        if (null == xxxClass) {
            Log.e(TAG, "Class SyncInfo cannot be found");
        }
        return xxxClass;
    }
}
